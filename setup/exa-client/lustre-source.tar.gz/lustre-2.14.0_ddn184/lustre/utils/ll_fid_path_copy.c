#include <errno.h>
#include <fcntl.h>
#include <getopt.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <linux/lustre/lustre_idl.h>
#include <lustre/lustreapi.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include "lstddef.h"


void usage(void)
{
	printf("Usage: %s [OPTION]...\n"
"Copy data from a file on Lustre (specified by fid) to a file specified by path\n"
"\n"
"Mandatory arguments to long options are mandatory for short options too.\n"
"  -d, --direct_io		use direct I/O\n"
"  -F, --source_fid [fid]	fid of source file for copy\n"
"  -h, --help			display this help and exit\n"
"  -l, --lustre_dir [dir]	path to a directory on Lustre\n"
"  -p, --destination_path	[path] path of destination for copy\n"
"  -s, --iosize [size]		do reads/writes of [size] bytes, must be 1 MiB aligned\n"
"  -t, --threads [num]		number of threads (default: 1)\n",
"ll_fid_path_copy");
}

static bool abort_copy;

struct chunk_data {
	ssize_t* copied_total;
	int extra_open_flags;
	size_t iosize;
	off_t offset;
	off_t end_offset;
	int src_fd;
	int dst_fd;
};

#define PERIODIC_CHECK_IOCOUNT	32

static bool check_abort_copy(int fd, int *iocount)
{
	if (abort_copy)
		return true;

	(*iocount)++;
	if (*iocount >= PERIODIC_CHECK_IOCOUNT) {
		struct lu_pcc_state state;
		int rc;

		*iocount = 0;
		rc = llapi_pcc_state_get_fd(fd, &state);
		if (rc) {
			fprintf(stderr,
				"%s: failed to get PCC state: rc = %d\n",
				program_invocation_short_name, rc);
			return false;
		}

		if (state.pccs_flags & PCC_STATE_FL_ATTACH_ABORTING)
			abort_copy = true;
	}

	return abort_copy;
}

void *copy_data_threaded(void *arg)
{
	struct chunk_data *chunk = arg;
	int extra_open_flags = chunk->extra_open_flags;
	ssize_t* copied_total = chunk->copied_total;
	off_t end_offset = chunk->end_offset;
	size_t page_size = sysconf(_SC_PAGESIZE);
	size_t iosize = chunk->iosize;
	off_t offset = chunk->offset;
	int src_fd = chunk->src_fd;
	int dst_fd = chunk->dst_fd;
	void* buf = NULL;
	ssize_t rc = 0;
	long int thread = syscall(__NR_gettid);
	int iocount = 0;

	rc = posix_memalign(&buf, page_size, iosize);
	if (rc) {
		fprintf(stderr, "%s: memalign failed, thread %ld, size %lu: rc = %ld\n",
			program_invocation_short_name, thread, iosize, rc);
		return NULL;
	}

	while (1) {
		ssize_t rsz;
		ssize_t wsz;

		rsz = pread(src_fd, buf, iosize, offset);
		if (rsz < 0) {
			rc = -errno;
			fprintf(stderr,
				"%s: failed to read from source thread %ld, rc = %ld\n",
				program_invocation_short_name, thread, rc);
			break;
		}

		/* EOF, copy is done */
		if (rsz == 0)
			break;

		/* Retry writing if interrupted */
	retry_write:
		wsz = pwrite(dst_fd, buf, rsz, offset);
		if (wsz < 0) {
			rc = -errno;

			/* Unaligned direct IO reports error code -EINVAL on the
			 * local file system (such as Ext4). In this case,
			 * fallback to buffered IO.
			 */
			if (extra_open_flags & O_DIRECT && rc == -EINVAL) {
				extra_open_flags &= ~O_DIRECT;
				rc = fcntl(dst_fd, F_SETFL, extra_open_flags);
				if (rc < 0) {
					rc = -errno;
					fprintf(stderr,
						"%s: failed to clear O_DIRECT flag: rc = %ld",
						program_invocation_short_name, rc);
					break;
				}
				rc = 0;
				goto retry_write;
			}

			fprintf(stderr,
				"%s: failed to write destination: rc = %ld\n",
				program_invocation_short_name, rc);
			break;
		}

		*copied_total += wsz;
		offset += wsz;
		if (offset == end_offset)
			break;

		if (check_abort_copy(src_fd, &iocount))
			break;
	}

	free(buf);
	return NULL;
}

static ssize_t ll_fid_path_copy(const char* lustre_path,
				const struct lu_fid* src_fid,
				const char* dst_path, size_t iosize,
				int extra_open_flags, int num_threads)
{
	struct chunk_data *thread_chunks = NULL;
	ssize_t* copied_totals = NULL;
	pthread_t* threads = NULL;
	int max_threads_for_size;
	struct stat stbuf;
	off_t chunk_size;
	off_t offset = 0;
	int src_fd = -1;
	int dst_fd = -1;
	ssize_t rc = 0;
	int i;

	/* Open source file */
	src_fd = llapi_open_by_fid(lustre_path, src_fid,
				   O_RDONLY | extra_open_flags);
	if (src_fd < 0) {
		rc = -errno;
		fprintf(stderr,
			"%s: failed to open source %s/" DFID ": rc = %ld\n",
			program_invocation_short_name, lustre_path,
			PFID(src_fid), rc);
		return rc;
	}

	/* Get source file information */
	rc = fstat(src_fd, &stbuf);
	if (rc < 0) {
		fprintf(stderr,
			"%s: failed to stat source %s/" DFID ": rc = %ld\n",
			program_invocation_short_name, lustre_path,
			PFID(src_fid), rc);
		goto out;
	}

	/* Open destination file */
	dst_fd = open(dst_path, O_WRONLY | O_LARGEFILE | extra_open_flags);
	if (dst_fd < 0) {
		rc = -errno;
		fprintf(stderr,
			"%s: failed to open destination %s: rc = %ld\n",
			program_invocation_short_name, dst_path, rc);
		goto out;
	}

	/* Calculate the maximum number of threads that can be used based on
	 * file size and iosize.
	 *
	 * This assumes the cost of starting a thread is broadly similar to the
	 * cost of doing a single IO, which is reasonable because threads are
	 * cheap to spawn and read-write ops are relatively expensive.
	 *
	 * But because of synchronization/waiting overhead, etc, we do at least
	 * 2 instead of 1 IO per thread.
	 */
	max_threads_for_size = stbuf.st_size / (iosize * 2);

	if (max_threads_for_size == 0)
		max_threads_for_size = 1;

	/* Adjust the number of threads based on the file size and iosize */
	num_threads = min(num_threads, max_threads_for_size);

	/* Calculate the initial chunk_size with the adjusted num_threads */
	chunk_size = (stbuf.st_size + num_threads - 1) / num_threads;

	/* Round chunk_size to the next iosize */
	chunk_size += iosize - (chunk_size % iosize);

	/* allocate thread tracking info */
	threads = malloc(num_threads * sizeof(pthread_t));
	copied_totals = malloc(num_threads * sizeof(ssize_t));
	thread_chunks = malloc(num_threads * sizeof(struct chunk_data));

	for (i = 0; i < num_threads; i++) {
		int result;

		copied_totals[i] = 0;

		thread_chunks[i].src_fd = src_fd;
		thread_chunks[i].dst_fd = dst_fd;
		thread_chunks[i].iosize = iosize;
		thread_chunks[i].extra_open_flags = extra_open_flags;
		thread_chunks[i].offset = offset;
		thread_chunks[i].end_offset = offset + chunk_size;
		thread_chunks[i].copied_total = &copied_totals[i];

		result = pthread_create(&threads[i], NULL, (void* (*)(void*))copy_data_threaded,
					&thread_chunks[i]);
		if (result != 0) {
			fprintf(stdout,
				"%s: failed to create thread %d: %d\n",
				program_invocation_short_name, i, result);
			rc = -result;
			goto join_threads;
		}

		offset += chunk_size;
	}

join_threads:
	for (i = 0; i < num_threads; i++) {
		if (pthread_join(threads[i], NULL) != 0) {
			fprintf(stdout, "%s: failed to join thread %d\n",
				program_invocation_short_name, i);
			rc = -1;
		}

		/* Accumulate the total copied bytes */
		rc += copied_totals[i];
	}

	if (rc != stbuf.st_size) {
		fprintf(stdout,
			"%s: incomplete copy: copied %lu bytes of %lu\n",
			program_invocation_short_name, rc, stbuf.st_size);
		rc = -EIO;
	}

out:
	if (src_fd > 0)
		close(src_fd);

	if (dst_fd > 0)
		close(dst_fd);

	free(threads);
	free(copied_totals);
	free(thread_chunks);

	return rc;
}

#define MAX_THREADS 255

int main(int argc, char* argv[]) {
	static struct option options[] = {
		{ .name = "direct_io", .has_arg = no_argument, .val = 'd' },
		{ .name = "src_fid", .has_arg = required_argument, .val = 'F' },
		{ .name = "help", .has_arg = no_argument, .val = 'h' },
		{ .name = "lustre_path", .has_arg = required_argument, .val = 'l' },
		{ .name = "dst_path", .has_arg = required_argument, .val = 'p' },
		{ .name = "iosize", .has_arg = required_argument, .val = 's' },
		{ .name = "threads", .has_arg = required_argument, .val = 't' },
	};
	int extra_open_flags = 0;
	char* lustre_path = NULL;
	char* dst_path = NULL;
	struct lu_fid src_fid;
	char* fidstr = NULL;
	int num_threads = 1;
	size_t iosize = 0;
	ssize_t rc = 0;
	int c;

	while ((c = getopt_long(argc, argv, "dF:hl:p:s:t:", options, NULL)) != -1) {
		switch (c) {
			case 'd':
				extra_open_flags = O_DIRECT;
				break;
			case 'F':
				fidstr = optarg;
				break;
			case 'h':
				usage();
				exit(EXIT_SUCCESS);
				break;
			case 'l':
				lustre_path = optarg;
				break;
			case 'p':
				dst_path = optarg;
				break;
			case 's':
				iosize = strtol(optarg, NULL, 0);
				break;
			case 't':
				num_threads = atoi(optarg);
				break;
		}
	}

	if (!fidstr) {
		fprintf(stderr, "%s: Must provide a source fid.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (!dst_path) {
		fprintf(stderr, "%s: Must provide destination path.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (!lustre_path) {
		fprintf(stderr, "%s: Must provide Lustre path.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (iosize == 0) {
		fprintf(stderr, "%s: Must provide iosize.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (iosize % (1024 * 1024) != 0) {
		fprintf(stderr, "%s: iosize (%lu) must be 1 MiB aligned\n",
			program_invocation_short_name, iosize);
		usage();
		exit(EXIT_FAILURE);
	}

	if (num_threads < 1 || num_threads > MAX_THREADS) {
		fprintf(stderr,
			"%s: number of threads (%d) must be > 0 and <= %u\n",
			program_invocation_short_name, num_threads,
			MAX_THREADS);
		usage();
		exit(EXIT_FAILURE);
	}

	fprintf(stdout, "Copying from %s to %s, iosize %lu, using %s I/O with %d threads\n",
		fidstr, dst_path, iosize,
		(extra_open_flags == 0 ? "buffered" : "direct"), num_threads);

	rc = llapi_fid_parse(fidstr, &src_fid, NULL);
	if (rc < 0) {
		fprintf(stderr, "%s: Failed to parse fid: %s\n",
			program_invocation_short_name, fidstr);
		exit(EXIT_FAILURE);
	}

	rc = ll_fid_path_copy(lustre_path, &src_fid, dst_path, iosize,
			      extra_open_flags, num_threads);
	if (rc < 0)
		exit(EXIT_FAILURE);

	fprintf(stdout, "Successfully copied %lu bytes from %s to %s.\n",
		rc, fidstr, dst_path);

	exit(EXIT_SUCCESS);
}

