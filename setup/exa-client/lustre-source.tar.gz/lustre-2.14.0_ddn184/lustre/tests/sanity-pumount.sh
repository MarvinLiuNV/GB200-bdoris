#!/bin/bash

set -e

ONLY=${ONLY:-"$*"}
ALWAYS_EXCEPT="$SANITY_PUMOUNT_EXCEPT"
# UPDATE THE COMMENT ABOVE WITH BUG NUMBERS WHEN CHANGING ALWAYS_EXCEPT!

SRCDIR=$(dirname $0)
PATH=$PWD/$SRCDIR:$SRCDIR:$SRCDIR/../utils:$SRCDIR/../../pumount:$PATH

CHECKSTAT=${CHECKSTAT:-"checkstat -v"}
OPENFILE=${OPENFILE:-openfile}
OPENUNLINK=${OPENUNLINK:-openunlink}
MULTIOP=${MULTIOP:-multiop}
MOUNT_2=${MOUNT_2:-"yes"}
SAVE_PWD=$PWD

export TMP=${TMP:-/tmp}
export NAME=${NAME:-local}

LUSTRE=${LUSTRE:-`dirname $0`/..}
. $LUSTRE/tests/test-framework.sh
CLEANUP=${CLEANUP:-:}
SETUP=${SETUP:-:}
init_test_env "$@"
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
get_lustre_env
init_logging

FAIL_ON_ERROR=false
SETUP=${SETUP:-:}
TRACE=${TRACE:-""}

check_and_setup_lustre

assert_DIR
rm -rf $DIR1/[df][0-9]* $DIR1/lnk $DIR/[df].${TESTSUITE}*

type pumount || skip_env "pumount is not installed"

# $RUNAS_ID may get set incorrectly somewhere else
[ $UID -eq 0 -a $RUNAS_ID -eq 0 ] && error "\$RUNAS_ID set to 0, but \$UID is also 0!"

check_runas_id $RUNAS_ID $RUNAS_GID $RUNAS

build_test_filter

declare -a MOUNT_LIST=("$MOUNT1" "$MOUNT2")
declare -A MOUNT_NAME # Array mapping $MOUNTx to $(lfs getname $MOUNTx)
declare -A SAVED_MOUNT
declare -r SIGKILL=9
declare -r SIGUSR1=10
declare -r SIGUSR2=12
declare -r SIGTERM=15
declare -r SIGCHLD=17 # Ignored by default.
declare SLEEP_TIME=60
declare WAIT_TIME=30

function sanity_pumount_init() {
	local mount

	for mount in "${MOUNT_LIST[@]}"; do
		if mountpoint --quiet "$mount"; then
			SAVED_MOUNT[$mount]=true
		fi

		umount_client "$mount" || true
		mount_client "$mount"
	done
}

function sanity_pumount_fini() {
	local mount

	for mount in "${MOUNT_LIST[@]}"; do
		umount_client "$mount" || true

		if ${SAVED_MOUNT[$mount]:-false}; then
			mount_client "$mount"
		fi
	done
}

function init_pumount_env() {
	local mount

	for mount in "${MOUNT_LIST[@]}"; do
		mount_client "$mount"

		MOUNT_NAME["$mount"]=$($LFS getname "$mount")
	done
}

function check_mounted() {
	local mount

	for mount in "$@"; do
		mountpoint --quiet "$mount" || error "'$mount' not mounted"
	done
}

function check_unmount_complete() {
	local mount="$1"

	# Check if lazy umount of $mount is complete.
	#
	# When umount2($mount, MNT_DETACH) returns
	#   1. The mount at $mount will be detached from the namespace.
	#   2. $mount will no longer appear in /proc/[pid]/mountinfo for any pid.
	#
	# *But* the lite instance param remains after the lazy umount
	# command returns and exists until the last reference is
	# dropped and the umount completes.

	# mountpoint uses /proc/self/mountinfo
	mountpoint --quiet "$mount" && error "'$mount' still mounted"
	$LCTL list_param "llite.${MOUNT_NAME[$mount]}" 2> /dev/null &&
		error "unmount of '$mount' did not complete"

	return 0
}

function wait_for_open() {
	local pid="$1"
	local path="$2"
	local fd="${3:-0-1024}"
	local deadline=$((SECONDS + WAIT_TIME))

	[[ -e "$path" ]] || error "'$path' does not exist"

	while ((SECONDS < deadline)); do
		if lsof -a -d "$fd" -p "$pid" -- "$path"; then
			return 0
		fi

		sleep 1
	done

	error "pid '$pid' failed to open '$path'"
}

function wait_for_exec() {
	wait_for_open "$1" "$2" txt
}

function wait_for_mmap() {
	wait_for_open "$1" "$2" mem
}

function wait_signaled() {
	local pid=$1
	local sig=$2
	local status

	wait "$pid"
	status=$?

	((status == 128 + sig)) || error "pid $pid terminated with status $status, expected $((128 + sig))"
}

function kill_wait_signaled() {
	local pid=$1
	local sig_to_send=$2
	local sig_to_expect=$3
	local status

	# Send sig_to_send to PID but check that it already terminated by sig_to_expect.
	kill "-${sig_to_send}" "${pid}" # May fail.
	wait "$pid"
	status=$?

	((status == 128 + sig_to_expect)) ||
		error "pid $pid terminated with status $status, expected $((128 + sig_to_expect))"
}

sanity_pumount_init

test_20a() {
	init_pumount_env

	pumount "$MOUNT1" || error "pumount failed"
	check_unmount_complete "$MOUNT1"
	check_mounted "$MOUNT2"
}
run_test 20a "pumount works"

test_20b() {
	init_pumount_env
	umount_client "$MOUNT2"
	if pumount "$MOUNT2"; then
		error "pumount should fail"
	fi
}
run_test 20b "pumount fails on non mount point"

test_20c() {
	local option

	for option in --dry-run --no-open --no-signal --no-umount --print; do
		init_pumount_env
		umount_client "$MOUNT2"

		if pumount $option "$MOUNT2"; then
			error "'pumount $option' should fail"
		fi
	done
}
run_test 20c "pumount with options fails on non mount point"

test_21a() {
	local file=$DIR/$tfile
	local pid

	init_pumount_env

	echo ZZZ > "$file"
	$MULTIOP "$file" o_c &
	pid=$!
	wait_for_open "$pid" "$file"

	pumount "$MOUNT1" || error "pumount failed"
	wait_signaled $pid $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 21a "pumount works with an open file (multiop)"

test_22a() {
	local file=$DIR/$tfile
	local pid

	init_pumount_env

	dd if=/dev/zero of="$file" bs=4K count=1
	$MULTIOP "$file" OsMc_ &
	pid=$!
	wait_for_mmap "$pid" "$file"

	pumount "$MOUNT1" || error "pumount failed"
	wait_signaled $pid $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 22a "pumount works with an mmapped file (multiop)"

test_22b() {
	local file=$DIR/$tfile
	local pid

	init_pumount_env

	dd if=/dev/zero of="$file" bs=4K count=1
	$MULTIOP "$file" OsMc_ &
	pid=$!
	wait_for_mmap "$pid" "$file"
	rm "$file"

	pumount "$MOUNT1" || error "pumount failed"
	wait_signaled $pid $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 22b "pumount works with a deleted mmapped file (multiop)"

test_30a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	# This is less racy than 'sleep $SLEEP_TIME > $file &'.
	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 30a "pumount works with an open file (2)"

test_30b() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	# This is less racy than 'sleep $SLEEP_TIME > $file &'.
	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount --no-open "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 30b "pumount --no-open works with an open file (2)"

test_31a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	rm "$file"

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 31a "pumount works with a deleted open file"

test_31b() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	mv "$file" "$file-1"

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 31b "pumount works with a renamed open file"

test_31c() {
	local dir="$DIR/$tdir"
	local fd
	local pid

	init_pumount_env

	mkdir "$dir"
	exec {fd}<"$dir"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}<&-

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 31c "pumount works with an open directory"

test_31d() {
	local dir="$DIR/$tdir"
	local fd
	local pid

	init_pumount_env

	mkdir "$dir"
	exec {fd}<"$dir"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}<&-
	rmdir "$dir"

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 31d "pumount works with a removed open directory"

test_31e() {
	local file="$DIR/$tfile"
	local fd
	local pid

	init_pumount_env

	mkfifo "$file"
	exec {fd}<>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 31e "pumount works with a fifo"

test_32a() {
	local sleep=$DIR/sleep
	local pid

	init_pumount_env
	cp /usr/bin/sleep $sleep

	$sleep $SLEEP_TIME &
	pid=$!
	wait_for_exec "$pid" "$sleep"

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 32a "pumount works with an executable"

test_32b() {
	local sleep=$DIR/sleep
	local pid

	init_pumount_env
	cp /usr/bin/sleep $sleep

	$sleep $SLEEP_TIME &
	pid=$!
	wait_for_exec "$pid" "$sleep"
	rm $sleep

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 32b "pumount works with a deleted executable"

test_32c() {
	local sleep=$DIR/sleep
	local pid

	init_pumount_env
	cp /usr/bin/sleep $sleep

	$sleep $SLEEP_TIME &
	pid=$!
	wait_for_exec "$pid" "$sleep"
	mv $sleep $sleep-1

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 32c "pumount works with a renamed executable"

test_33a() {
	local pid

	init_pumount_env

	pushd $DIR
	sleep $SLEEP_TIME &
	pid=$!
	wait_for_open "$pid" "$DIR" cwd
	popd

	pumount "$MOUNT1" || error "pumount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 33a "pumount works on CWDs"

test_34a() {
	local file=$DIR2/$tfile
	local pid

	init_pumount_env

	/usr/bin/sleep $SLEEP_TIME > "$file" &
	pid=$!
	wait_for_exec "$pid" /usr/bin/sleep

	pumount "$MOUNT1" || error "pumount failed"
	# pumount would send SIGKILL, we send and expect SIGUSR2.
	kill_wait_signaled $pid $SIGUSR2 $SIGUSR2
	check_unmount_complete "$MOUNT1"
}
run_test 34a "pumount does not kill processes on other mount points"

test_40a() {
	init_pumount_env

	stop mds1 || error "cannot stop mds1"
	pumount "$MOUNT1" || error "pumount failed"
	check_unmount_complete "$MOUNT1"
	start mds1 $(mdsdevname 1) || error "cannot start mds1"
}
run_test 40a "pumount works wih MDT0000 unmounted"

test_40b() {
	init_pumount_env
	ls -al "$MOUNT1" "$MOUNT1" "$MOUNT1"

	stop mds1 || error "cannot stop mds1"
	pumount "$MOUNT1" || error "pumount failed"
	check_unmount_complete "$MOUNT1"
	start mds1 $(mdsdevname 1) || error "cannot start mds1"
}
run_test 40b "pumount works wih MDT0000 unmounted (2)"

test_40c() {
	local file=$DIR/$tfile
	local instance
	local pid

	init_pumount_env

	instance=$($LFS getname --instance "$MOUNT1")
	lctl set_param "*.*-${instance}.allow_intr=1"

	/usr/bin/sleep $SLEEP_TIME > "$file" &
	pid=$!
	wait_for_exec "$pid" /usr/bin/sleep

	stop mds1 || error "cannot stop mds1"
	pumount "$MOUNT1" || error "pumount failed"
	check_unmount_complete "$MOUNT1"
	wait $pid
	start mds1 $(mdsdevname 1) || error "cannot start mds1"
}
run_test 40c "pumount works wih MDT0000 unmounted (3)"

test_41a() {
	local pid

	init_pumount_env

	stop ost1 || error "cannot stop ost1"
	pumount "$MOUNT1" || error "pumount failed"
	check_unmount_complete "$MOUNT1"
	start ost1 $(ostdevname 1)  || error "cannot start ost1"
}
run_test 41a "pumount works wih OST0000 unmounted"

# TODO run_test XX "pumount works with a chroot"

test_50a() {
	pumount --help || error "pumount --help failed"
}
run_test 50a "pumount --help works"

test_50b() {
	pumount --version || errro "pumount --version failed"
}
run_test 50b "pumount --version works"

test_51a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount --dry-run "$MOUNT1" |
	awk -v pid=$pid '$2 == pid' | grep . ||
		error "dry-run did not show PID $pid"

	kill_wait_signaled $pid $SIGUSR2 $SIGUSR2
	check_mounted "$MOUNT1"
}
run_test 51a "pumount --dry-run works"

test_52a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount --force "$MOUNT1" || error "pumount --force failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 52a "pumount --force works"

test_53a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount --no-signal "$MOUNT1" || error "pumount --no-signal failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGUSR2
	check_unmount_complete "$MOUNT1"
}
run_test 53a "pumount --no-signal works"

test_54a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-

	pumount --no-umount "$MOUNT1" || error "pumount --no-umount failed"
	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_mounted "$MOUNT1"
}
run_test 54a "pumount --no-umount works"

test_55a() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	# pumount --print fields
	# COMM=1 PID=2 REF=3 HANDLE_TYPE=4 HANDLE=5 PATH=6
	# REF is exe, cwd, rtd, map, or an FD
	pumount --print "$MOUNT1" | awk '$1 == "sleep"' | grep . ||
		error "pumount --print COMM != SLEEP'"

	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 55a "pumount --print shows the right comm"

test_55b() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	pumount --print "$MOUNT1" | awk -v pid=$pid '$2 == pid' | grep . ||
		error "pumount --print PID != $pid'"

	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 55b "pumount --print shows the right PID"

test_55c() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	pumount --print "$MOUNT1" | awk -v fd="$fd" '$3 == fd' | grep . ||
		error "pumount --print FD != $fd"

	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 55c "pumount --print shows the right FD"

test_55d() {
	local file=$DIR/$tfile
	local fd
	local fid
	local pid

	init_pumount_env

	exec {fd}>"$file"
	fid=$($LFS path2fid "$file")
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	pumount --print "$MOUNT1" | awk -v fid="$fid" '$4 == "lustre" && $5 == fid' | grep . ||
		error "pumount --print HANDLE_TYPE != 'lustre' or FID != '$fid'"

	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 55d "pumount --print shows the right handle type and FID"

test_55e() {
	local file=$DIR/$tfile
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	# XXX path changes after umount2(..., MNT_DETACH) from '/mnt/$FSNAME/$tfile' to '/$tfile'
	pumount --print "$MOUNT1" | awk -v path="/$tfile" '$6 == path' | grep . ||
		error "pumount --print PATH != '/$tfile'"

	kill_wait_signaled $pid $SIGUSR2 $SIGKILL
	check_unmount_complete "$MOUNT1"
}
run_test 55e "pumount --print shows the right path (sort of)"

test_55f() {
	local dir=$(readlink --canonicalize "$DIR")
	local name_esc='.\014\023\024\022:VOLATILE:0000:55f055f0'
	local file=$(printf "%s/${name_esc}" "$dir")
	local path
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	# COMM=1 PID=2 REF=3 HANDLE_TYPE=4 HANDLE=5 PATH=6
	path=$(pumount --dry-run "$MOUNT1" |
		awk -v pid=$pid -v fd=$fd '$2 == pid && $3 == fd { print $6; }')

	[[ "${path}" == "${dir}/${name_esc}" ]] ||
		error "got escaped path '${path}, expected '${dir}/${name_esc}'"

	kill_wait_signaled $pid $SIGKILL $SIGKILL
}
run_test 55f "pumount escapes volatile file paths correctly"

test_55g() {
	local dir=$(readlink --canonicalize "$DIR")
	local file="$DIR/$tfile $tfile"
	local path_esc="${dir}/${tfile}\040${tfile}"
	local path
	local fd
	local pid

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	# COMM=1 PID=2 REF=3 HANDLE_TYPE=4 HANDLE=5 PATH=6
	path=$(pumount --dry-run "$MOUNT1" |
		awk -v pid=$pid -v fd=$fd '$2 == pid && $3 == fd { print $6; }')

	[[ "${path}" == "${path_esc}" ]] ||
		error "got escaped path '${path}', expected '${path_esc}'"

	kill_wait_signaled $pid $SIGKILL $SIGKILL
}
run_test 55g "pumount escapes paths with spaces correctly"

test_56a() {
	local file=$DIR/$tfile
	local fd
	local pid

	for sig in SIGTERM sigterm TERM term $SIGTERM; do
		init_pumount_env

		exec {fd}>"$file"
		/usr/bin/sleep $SLEEP_TIME &
		pid=$!
		exec {fd}>&-
		wait_for_exec "$pid" /usr/bin/sleep

		pumount --signal=$sig "$MOUNT1" || error "pumount --signal failed"
		kill_wait_signaled $pid $SIGUSR2 $SIGTERM
		check_unmount_complete "$MOUNT1"
	done
}
run_test 56a "pumount --signal works"

test_57a() {
	local file=$DIR/$tfile
	local fd
	local pid
	local status

	init_pumount_env

	exec {fd}>"$file"
	/usr/bin/sleep $SLEEP_TIME &
	pid=$!
	exec {fd}>&-
	wait_for_exec "$pid" /usr/bin/sleep

	status=0
	pumount --signal=$SIGCHLD "$MOUNT1" || status=$?
	((status == 1)) || error "pumount exited with status $status, expected 1"

	! mountpoint --quiet "$MOUNT1" || error "'$MOUNT1' still in mountinfo"
	kill_wait_signaled $pid $SIGTERM $SIGTERM
	check_unmount_complete "$MOUNT1"
}
run_test 57a "pumount fails with status 1 when processes remain"

test_57b() {
	local status

	init_pumount_env
	umount_client "$MOUNT2"
	
	status=0
	pumount "$MOUNT2" || status=$?
	((status == 2)) || error "pumount exited with status $status, expected 2"
}
run_test 57b "pumount fails with status 2 when umount fails"

test_57c() {
	local status

	status=0
	pumount || status=$?
	((status == 3)) || error "pumount exited with status $status, expected 3"
}
run_test 57c "pumount fails with status 3 on invalid usage"

log "cleanup: ======================================================"

sanity_pumount_fini

# kill and wait in each test only guarentee script finish, but command in script
# like 'rm' 'chmod' may still be running, wait for all commands to finish
# otherwise umount below will fail
[ "$(mount | grep $MOUNT2)" ] && wait_update $HOSTNAME "fuser -m $MOUNT2" "" ||
	true

complete_test $SECONDS
check_and_cleanup_lustre
exit_status
