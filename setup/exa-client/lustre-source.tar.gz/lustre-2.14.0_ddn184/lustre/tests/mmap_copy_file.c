/*
 * GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright 2023 DDN Inc. All rights reserved.
 * Authors: Patrick Farrell <pfarrell@whamcloud.com>
 *
 * Simple program to copy a file using mmap.  Created to test client side data
 * compression feature.
 *
 * Syncs data after each write in order to force compression to act on partial
 * chunks of data.
 */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

/* < minimum chunk size of 64K and not-chunk or page aligned */
#define DEFAULT_BLOCK_SIZE (35 * 1024) /* 35K */

int main(int argc, char *argv[]) {
	struct stat src_stat;
	unsigned int random_seed = (unsigned int)time(NULL);
	size_t block_size = DEFAULT_BLOCK_SIZE;
	const char *src_filename;
	const char *dst_filename;
	size_t bytes_copied = 0;
	float percentage = 1.0;
	size_t remaining_size;
	size_t chunks_to_copy;
	int partial_copy = 0;
	size_t copy_size;
	void *dst_map;
	size_t offset;
	void *src_map;
	int src_fd;
	int dst_fd;
	int opt;

	while ((opt = getopt(argc, argv, "p:s:b:")) != -1) {
		switch (opt) {
			case 'p':
				partial_copy = 1;
				percentage = atof(optarg) / 100.0;
				if (percentage <= 0.01 || percentage > 1.0) {
					fprintf(stderr,
						"Percentage must be between 1 and 100\n");
					return 1;
				}
				break;
			case 's':
				random_seed = (unsigned int)atoi(optarg);
				break;
			case 'b':
				block_size = atoi(optarg);
				if (block_size <= 0) {
					fprintf(stderr, "Block size must be greater than 0\n");
					return 1;
				}
				break;
			default:
				fprintf(stderr, "Usage: %s [-p PERCENT_TO_COPY(1-100)] [-s SEED] [-b BLOCK_SIZE] <source_file> <destination_file>\n",
					argv[0]);
			return 1;
		}
	}

	if (optind + 2 > argc) {
		fprintf(stderr,
			"Usage: %s [-p PERCENT_TO_COPY(1-100)] [-s SEED] <source_file> <destination_file>\n",
			argv[0]);
		return 1;
	}

	src_filename = argv[optind];
	dst_filename = argv[optind + 1];

	src_fd = open(src_filename, O_RDONLY);
	if (src_fd == -1) {
		perror("Failed to open source file");
		return 1;
	}

	if (fstat(src_fd, &src_stat) == -1) {
		perror("Failed to get source file size");
		close(src_fd);
		return 1;
	}

	dst_fd = open(dst_filename, O_RDWR | O_CREAT, 0666);
	if (dst_fd == -1) {
		perror("Failed to create destination file");
		close(src_fd);
		return 1;
	}

	if (ftruncate(dst_fd, src_stat.st_size) == -1) {
		perror("Failed to set destination file size");
		close(src_fd);
		close(dst_fd);
		return 1;
	}

	src_map = mmap(NULL, src_stat.st_size, PROT_READ, MAP_PRIVATE, src_fd, 0);
	if (src_map == MAP_FAILED) {
		perror("Failed to mmap source file");
		close(src_fd);
		close(dst_fd);
		return 1;
	}

	dst_map = mmap(NULL, src_stat.st_size, PROT_WRITE, MAP_SHARED, dst_fd, 0);
	if (dst_map == MAP_FAILED) {
		perror("Failed to mmap destination file");
		munmap(src_map, src_stat.st_size);
		close(src_fd);
		close(dst_fd);
		return 1;
	}

	remaining_size = src_stat.st_size;
	offset = 0;

	if (partial_copy) {
		size_t total_chunks =
			src_stat.st_size / block_size + (src_stat.st_size % block_size != 0);
		size_t i;

		chunks_to_copy = total_chunks * percentage;

		srand(random_seed);
		for (i = 0; i < chunks_to_copy; i++) {
			offset = (rand() % (total_chunks - 1)) * block_size;
			copy_size = (src_stat.st_size - offset < block_size) ?
				src_stat.st_size - offset : block_size;
			memcpy(dst_map + offset, src_map + offset, copy_size);
			bytes_copied += copy_size;
			fsync(dst_fd);
		}
	} else {
		/* Existing copy logic */
		while (remaining_size > 0) {
			copy_size = (remaining_size < block_size) ?
				remaining_size : block_size;
			memcpy(dst_map + offset, src_map + offset, copy_size);
			offset += copy_size;
			remaining_size -= copy_size;
			bytes_copied += copy_size;
			fsync(dst_fd);
		}
	}
	munmap(src_map, src_stat.st_size);
	munmap(dst_map, src_stat.st_size);
	close(src_fd);
	close(dst_fd);

	if (!partial_copy)
		printf("File '%s' (%lu bytes) mmap-copied to '%s' successfully (block size %lu)!\n",
		       src_filename, bytes_copied, dst_filename, block_size);
	else
		printf("Copied %lu bytes (%d%%) of file '%s' (%lu total bytes) mmap-copied to '%s' successfully (block size %lu)!\n",
		       bytes_copied, (int)(percentage * 100), src_filename,
		       src_stat.st_size, dst_filename, block_size);

	return 0;
}

